package com.example.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Models.Info;
import com.example.Models.Register;
import com.example.Repository.Contact;
import com.example.Repository.SignUp;
@RestController
public class Contacts {
	@Autowired
	public Contact con;
	@RequestMapping("/contacts")
	public Info signUp(@RequestBody Info data) {
		Info r1=new Info();
		//boolean isExist=false;
		try {
			r1=con.findByEmail(data.getEmail());
			if(r1!=null) {
				r1.msg="exist";
			}
			else {
				r1.msg="done";
				con.save(data);
				
			}
		}
		catch(Exception e) {
			r1.msg="done";
			con.save(data);
		}
		
		return r1;
	}
}
