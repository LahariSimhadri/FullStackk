package com.example.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Models.Register;

public interface SignUp extends JpaRepository<Register, Long> {

	Register findByEmail(String email);

	

}
