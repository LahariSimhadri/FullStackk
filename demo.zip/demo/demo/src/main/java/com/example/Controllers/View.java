package com.example.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Models.Info;
import com.example.Repository.Contact;

@RestController
public class View {
	@Autowired
	public Contact con;
	@RequestMapping("/view")
	public Info signUp(@RequestBody Info data) {
		Info r1=new Info();
		//boolean isExist=false;
		try {
			r1=con.findByEmail(data.getEmail());
			return r1;
		}
		catch(Exception e) {
			return null;
		}
		
		
	}
	

}
