package com.example.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Models.Register;
import com.example.Repository.SignUp;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class SignUP {
	@Autowired
	public SignUp sig;
	@RequestMapping("/signup")
	public Register signUp(@RequestBody Register data) {
		Register r1=new Register();
		//boolean isExist=false;
		try {
			r1=sig.findByEmail(data.getEmail());
			if(r1!=null) {
				r1.msg="exist";
			}
			else {
				r1.msg="new";
				sig.save(data);
				
			}
		}
		catch(Exception e) {
			r1.msg="new";
			sig.save(data);
		}
		
		return r1;
	}

}
