package com.example.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.Models.Login;
import com.example.Models.Register;
import com.example.Repository.SignUp;

public class SignIn {
	@Autowired
	public SignUp sig;
	@RequestMapping("/signin")
	public Register signin(@RequestBody Login data) {
		Register r1=new Register();
		try {
			r1=sig.findByEmail(data.getEmail());
			if(r1!=null && r1.getPassword().equals(data.getPassword()) ) {
				r1.msg="valid";
			}
			else {
				r1.msg="invalid";
				
			}
		}
		catch(Exception e) {
			r1.msg="invalid";
			
		}
		
		return r1;
	}

}