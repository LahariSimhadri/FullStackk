package com.example.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Models.Info;



public interface Contact extends JpaRepository<Info, Long> {
	Info findByEmail(String email);
}
